import numpy as np
from tqdm import tqdm  

'''
tqdm可以展示进度

获取path中，根据word——index来得到的句子中的词索引的 一句话
'''

def load_glove_embedding(path, dim, word_index):
        embeddings_index = {}
        f = open(path)

        print('Generating GloVe embedding...')
        for line in tqdm(f): #按行分词
            values = line.split() 
            word = values[0] #分词
            coefs = np.asarray(values[1:], dtype='float32')  
            '''
            为什么是value[1:]?
            '''
            embeddings_index[word] = coefs #每一行的首词为索引 
        f.close()

        embedding_matrix = np.zeros((len(word_index) + 1, dim)) #形成len(word_index)+1行，dim列的矩阵

        for word, i in word_index.items():
            embedding_vector = embeddings_index.get(word) #根据word来获取剩下的词
            if embedding_vector is not None:
                # words not found in embedding index will be all-zeros.
                embedding_matrix[i] = embedding_vector 
        print('Loaded GloVe embedding')

        return embedding_matrix 