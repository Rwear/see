# -*- coding: utf-8 -*-
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
from keras.models import Model
from keras.layers import Dense, Input, Dropout, Embedding, Conv1D, GlobalMaxPooling1D, MaxPooling1D, Flatten, concatenate
from sklearn.metrics import roc_curve, auc, accuracy_score, precision_score, confusion_matrix
from keras.optimizers import Adam
from sklearn.model_selection import train_test_split
import numpy as np
np.random.seed(42)
import os
import gensim
import pickle
from keras.callbacks import *
from sklearn.metrics import f1_score, precision_score, recall_score, accuracy_score, roc_auc_score
from keras.utils.np_utils import to_categorical

dataset = 'politifact'

# create label
file_label = './data/' + dataset + '_news_label_r.pk'

f = open(file_label)
label = pickle.loads(f.read())
print('load data \"' + file_label + '\"')


file = './data/' + dataset + '_news_comment_latent.pk'
f = open(file)
com_model = pickle.loads(f.read())
print('load data \"' + file + '\"')

new_model = gensim.models.Doc2Vec.load('model/model_'+dataset+'_news')
sequences = []
for i in range(len(label)):
    sequences.append(np.hstack([new_model.docvecs[i], com_model[i]]))

sequences = np.array(sequences)
label = np.array(label)
X = sequences
y = label


# split training set and testing set
Xtrain,Xtest,ytrain,ytest=train_test_split(X,y,test_size=0.25, stratify=y, random_state=42)

nb_feature = 100
dim_hidden = 50
nb_feature_sub = 10

Xtrain_sub = np.array([x[100:] for x in Xtrain])
Xtrain = np.array([x[:100] for x in Xtrain])

Xtrain = Xtrain.reshape(len(Xtrain), 1, nb_feature)
Xtrain_sub = Xtrain_sub.reshape(len(Xtrain_sub), 1, nb_feature_sub)

Xtest_sub = np.array([x[100:] for x in Xtest])
Xtest = np.array([x[:100] for x in Xtest])

Xtest = Xtest.reshape(len(Xtest), 1, nb_feature)
Xtest_sub = Xtest_sub.reshape(len(Xtest_sub), 1, nb_feature_sub)

##### Main part #####
channel_in = 1
maxlen = 100
# conv layers
input = Input(shape=(None, nb_feature))
conv1 = Conv1D(nb_feature, kernel_size=1, activation='relu', strides=1)(input)
pool1 = GlobalMaxPooling1D()(conv1)
out1 = Dropout(0.5)(pool1)
out1 = Dense(10, activation='tanh')(out1)

##### Sub part #####
nb_score = 1
sub_input = Input(shape=(None, nb_feature_sub))
pool1 = GlobalMaxPooling1D()(sub_input)
out2 = Dropout(0.5)(pool1)
out2 = Dense(10, activation='softmax')(out2)


concat_out = concatenate([out1, out2])
outputs = Dense(1, activation='sigmoid')(concat_out)

model = Model(inputs=[input, sub_input], output=outputs)

adam = Adam(lr=0.001)
model.compile(loss='binary_crossentropy',optimizer='adam')

model.fit([Xtrain, Xtrain_sub], ytrain, batch_size=128, epochs=30)

preds = model.predict([Xtest, Xtest_sub], verbose=0)
preds = preds > 0.5
tn, fp, fn, tp = confusion_matrix(ytest, preds).ravel()
tn = float(tn)
tp = float(tp)
fp = float(fp)
print("%%% Test results {} samples %%%".format(len(ytest)))
print("accuracy: {}".format((tp + tn) / (tp + tn + fp + fn)))
print("precision : {:.4f}".format(tp / (tp + fp)))
print("recall : {:.4f}".format(tp / (tp + fn)))
print("F1 score : {:.4f}".format(2 * tp / (2 * tp + fp + fn)))