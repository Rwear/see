import gensim
import pickle
import os
from gensim.models.doc2vec import Doc2Vec, TaggedDocument
import csv
import sys
csv.field_size_limit(sys.maxsize)

dataset = 'politifact'

file_label = './data/' + dataset + '_content_no_ignore.tsv'

labels = []
processed_docs = []

with open(file_label) as tsvfile:
    reader = csv.reader(tsvfile, delimiter='\t')
    for row in reader:
        if row[1] =='label': continue
        labels.append(int(row[1]))
        processed_docs.append(row[2])
        print row[2]


file_comments = './data/' + dataset + '_comment_no_ignore.tsv'

processed_com = []

with open(file_comments) as tsvfile:
    reader = csv.reader(tsvfile, delimiter='\t')
    for row in reader:
        if row[1] == 'comment': continue
        processed_com.append(row[1])

file_label = './data/' + dataset + '_news_label_r.pk'

with open(file_label, 'w') as f:
    pickle.dump(labels, f)
print('data save in \"./data/' + dataset + '_news_label_r.pk\"')


processed_docs = [TaggedDocument(doc, [i]) for i, doc in enumerate(processed_docs)]
model = Doc2Vec(processed_docs, size=100, window=1, min_count=5, workers=8)
file = './model/model_' + dataset + '_news'
model.save(file)
print('model save in \"./model/model_'+dataset+'_news\"')

processed_docs = [TaggedDocument(doc, [i]) for i, doc in enumerate(processed_com)]
model = gensim.models.Doc2Vec(processed_docs, size=20, window=1, min_count=5, workers=8)
file = './model/model_' + dataset + '_comments'
model.save(file)
print('model save in \"./model/model_'+dataset+'_comments\"')