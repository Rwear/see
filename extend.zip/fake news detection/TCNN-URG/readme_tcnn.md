# TCNN-URG

We implement base on the algorithm described in the paper: [Neural User Response Generator: Fake News Detection with Collective User Intelligence](https://www.ijcai.org/proceedings/2018/0533.pdf), IJCAI, 2018.
 
## Files 
 The folder contains the data preprocessing files __process_data.py__ and __vae.py__, and the model file __tcnn.py__.

## Requirements
- Python 2.7.x
- Keras 2.0.x
- Gensim
- sklearn
- Numpy
 
## How to run

Note: This code is written in Python2.
```
python process_data.py
python vae.py
python tcnn.py
```